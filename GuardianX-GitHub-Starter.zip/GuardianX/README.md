# GuardianX

A small Java Discord moderation bot. The starter version removes Discord invite links posted by regular members. Members with the **Manage Messages** permission are exempt.

## Requirements

- Java 21
- Maven 3.9+
- A Discord application and bot token

## Discord setup

1. Create an application in the Discord Developer Portal.
2. Open the **Bot** page and create the bot if needed.
3. Enable **Message Content Intent** under Privileged Gateway Intents.
4. Invite the bot to your server with **View Channels**, **Read Message History**, **Send Messages**, and **Manage Messages** permissions.
5. Keep the bot token private. Never paste it into source code or commit it to GitHub.

## Run locally

Set an environment variable named `DISCORD_TOKEN` to your bot token.

PowerShell:
```powershell
$env:DISCORD_TOKEN = "YOUR_BOT_TOKEN"
mvn clean package
java -jar target/guardianx-1.0.0.jar
```

The Maven Shade plugin packages JDA into the runnable JAR.

## GitHub

Upload the project files to a GitHub repository. The `.gitignore` excludes local build output and `.env` files.

**Important:** GitHub is for storing the code. A normal GitHub repository does not keep a Discord bot running 24/7. To keep the bot online, deploy the JAR to a Java hosting service and add `DISCORD_TOKEN` as a private environment variable there.

## Current moderation behavior

- Ignores messages outside servers and messages sent by bots.
- Deletes messages containing `discord.gg/` from members who do not have **Manage Messages**.
- Sends a short notice after a successful deletion.

This is a clean starter project, not a recovery of the old `Database.java` features.
