package com.guardianx;

import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public final class ModerationListener extends ListenerAdapter {

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (!event.isFromGuild() || event.getAuthor().isBot()) {
            return;
        }

        String content = event.getMessage().getContentRaw();
        if (!content.toLowerCase().contains("discord.gg/")) {
            return;
        }

        Member member = event.getMember();
        if (member == null || member.hasPermission(Permission.MESSAGE_MANAGE)) {
            return;
        }

        event.getMessage().delete().queue(
                success -> event.getChannel()
                        .sendMessage(member.getAsMention() + " invite links are not allowed here.")
                        .queue(),
                error -> System.err.println("Could not delete invite link: " + error.getMessage())
        );
    }
}
